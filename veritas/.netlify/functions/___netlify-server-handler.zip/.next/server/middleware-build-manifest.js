globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/6b297c6bc770653d.js",
      "static/chunks/dd98a5ddb613bbe8.js",
      "static/chunks/turbopack-4302070eb3ca4573.js"
    ],
    "/_error": [
      "static/chunks/5a6c3db863a354ce.js",
      "static/chunks/dd98a5ddb613bbe8.js",
      "static/chunks/turbopack-aac89e2f82dd5933.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0fa8b9b47977c951.js",
    "static/chunks/fec0d9d73bbbc844.js",
    "static/chunks/9ff0436e3c4ca775.js",
    "static/chunks/afad78759262653c.js",
    "static/chunks/turbopack-e84b515adccfaee4.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];