var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__767101c0._.js")
R.c("server/chunks/c6b16_next_0b72cd5b._.js")
R.m(29216)
R.m(53481)
module.exports=R.m(53481).exports
