var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__1eb370ef._.js")
R.c("server/chunks/c6b16_next_dist_47a15bfa._.js")
R.c("server/chunks/c6b16_next_dist_81fce278._.js")
R.c("server/chunks/c6b16_next_d7e05815._.js")
R.m(15934)
R.m(94513)
module.exports=R.m(94513).exports
