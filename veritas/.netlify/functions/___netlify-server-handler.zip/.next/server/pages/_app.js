var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__de94c5c4._.js")
R.m(94151)
module.exports=R.m(94151).exports
