var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__4b3f9059._.js")
R.c("server/chunks/ssr/[root-of-the-server]__685427cf._.js")
R.m(11202)
module.exports=R.m(11202).exports
